#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <locale.h>

//Constntes indice das 2 tabelas Hash
#define H1 997 
#define H2 1000

int main () {
	//Ler arquivo e vai gerando as 2 hash de memoria
		// 1 - indice 997
		// 2 - indice 1000
	
	//iniciar HASH (tam)
		
	/* MENU
		-> Exibir estatisticas
		-> Efetuar busca por matricula
		-> Excluir por matricula
		-> Incluit Aluno
		-> Sair
	*/
}
