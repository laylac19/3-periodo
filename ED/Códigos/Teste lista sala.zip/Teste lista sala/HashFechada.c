//funcoes em si
	//iniciar HASH
	//Ler arquivo

HashF* incializeHash () { // iniciar a hash (tamanho)
	//primeira linha � o tamanho
}
