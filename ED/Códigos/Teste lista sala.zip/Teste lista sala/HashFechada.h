typedef struct Aluno {
	int matricula;
	char nome[50];
	int nota;
} TAluno; //T tipo aluno

typedef struct No {
	TAluno elem;
	struct no *prox;
} TNo;

typedef struct Lista {
	TNo *nodo;
} TLista;

typedef struct HashFechada {
	int tam;
	TElemento *dados; //dado
} HashF;

HashF incializeHash (Hash *h); // iniciar a hash (tamanho)

//hashFunction (tam hash) q retorna o indice

//inserir aluno na estrutura (manualmente)	

//consultar aluno

//exluir aluno

/*exibir estatistica
	-> qtde total
	-> media por indice
	-> indice com maior qtde de elem
		- qtde de elem no indice
	-> indice com menor qtde de elem
		- qtde de elem no indice
	-> desvio padrao da qtde de elem pelos indices
	-> indices no intervalo da media e desvio padrao
*/

//ler arquivo e gerar 2 tabelas hash fechadas
	// 1 - indice 997
	// 2 - indice 1000
	//primeira linha n�mero inteiro quantidade de registros de aluno no arquivo;

