#include <stdio.h>
#include <stdlib.h>

typedef struct {
	char nome[50];
	int cpf;
} Pessoa;

typedef struct no {
	Pessoa pessoa;
	struct no *esq, *dir;
}No;

/*
typedef struct {
	No *raiz; //raiz da arvore
	int tam;//qtde ou tam == quant de nós
}ArvB;
*/

Pessoa lerPessoa() {
	Pessoa p;
	printf("\n Digite o nome da pessoa: ");
	fgets(p.nome, 49, stdin);

	printf("\n Digite o CPF: ");
	scanf("%d", &p.cpf);	

	return p;
}

void imprimirPessoa (Pessoa p) {
	printf("\n Nome: %s \t CPF: %d", p.nome, p.cpf);
}

No* inserir (No *raiz, Pessoa p) {
	if (raiz == NULL) {
		No *aux = malloc(sizeof(No));
		aux->pessoa = p;
		aux->esq = NULL;
		aux->dir = NULL;
		return aux;
	}
	else {
		if (p.cpf < raiz->pessoa.cpf) {
			raiz->esq = inserir (raiz->esq, p);
		}
		else {
			raiz->dir = inserir (raiz->dir, p);
		}
		return raiz;
	}
}

No* buscar (No *raiz, int cpf) {
	if (raiz) {
		if (cpf == raiz->pessoa.cpf) {
			return raiz;
		}
		else if (cpf < raiz->pessoa.cpf) {
			return buscar (raiz->esq, cpf);
		}
		else {
			return buscar (raiz->dir, cpf);
		}
	}
	return NULL;
}

int altura (No *raiz) {
	if (raiz == NULL) {
		return -1;
	}
	else {
		int esq = altura (raiz->esq);
		int dir = altura (raiz->dir);
		if (esq > dir) {
			return esq + 1;
		}
		else {
			return dir + 1;
		}
	}
}

int quantidadeNos (No *raiz) {
	if (raiz == NULL) {
		return 0;
	}
	else {
		return 1 + quantidadeNos (raiz->esq) + quantidadeNos (raiz->dir);
	}
}

int quantidadeFolhas (No *raiz) {
	if (raiz == NULL) {
		return 0;
	}
	else if (raiz->esq == NULL && raiz->dir == NULL) {
		return 1;
	}
	else {
		return quantidadeFolhas (raiz->esq) + quantidadeFolhas (raiz->dir);
	}
}

No* remover (No *raiz, int chave) {
	if (raiz == NULL) {
		printf("Valor nao escontrado. \n");
		return NULL;
	}
	else { //percorre o nó pra remover
		if (raiz->pessoa.cpf == chave) {
			//remove as folhas (no sem filhos)
			if (raiz->esq == NULL && raiz->dir == NULL) {
				free(raiz); //remove a folha
				return NULL;
			}
			else {
				//remove nos com 2 filhos
				if (raiz->esq != NULL && raiz->dir != NULL) {
					Pessoa p;
					No *aux = raiz->esq;
					while (aux->dir != NULL) {
						aux = aux->dir;
					}
					p = raiz->pessoa;
					raiz->pessoa = aux->pessoa;
					aux->pessoa = p;
					//trocou os elementos (a pessoa interia)
					raiz->esq = remover (raiz->esq, chave);
				}
				else {
					//remove folha com 1 filho
					No *aux; //guarda o endereço do filho
					if (raiz->esq != NULL) {
						aux = raiz->esq;
					}
					else {
						aux = raiz->dir;
					}
					free(raiz); 
					return aux;
				}
			}
		}
		else {
			if (chave < raiz->pessoa.cpf) {
				raiz->esq = remover (raiz->esq, chave); 
			}
			else {
				raiz->dir = remover (raiz->dir, chave);
			}
		}
	}
}

void show1 (No *raiz) { //recursiva 
	//50 25 30 100
	if (raiz) {
		imprimirPessoa (raiz->pessoa);
		show1 (raiz->esq);
		show1 (raiz->dir);
	}
}

void show2 (No *raiz) {
	//25 30 50 100
	if (raiz) {
		show2 (raiz->esq);
		imprimirPessoa (raiz->pessoa);
		show2 (raiz->dir);
	}
}

int main(int argc, char const *argv[]) {
	No *busca, *raiz = NULL;
	int op, valor;

	do {
		printf("\n 0 - sair \n 1 - inserir \n 2 - imprimir \n 3 - buscar \n 4 - altura da arvore \n 5 - quantidade Nos \n 6 - quantidade Folhas \n 7 - remover \n");
		scanf("\n %d", &op);
		scanf("%c");

		switch(op) {
			case 0:
				printf("\n SAINDO \n");
				break;
			case 1:
				inserir (&raiz, lerPessoa());
				break;
			case 2:
				printf("\n\t SAIDA 1");
				show1 (raiz);
				printf("\n");

				printf("\n\t SAIDA 2");
				show2 (raiz);
				printf("\n");
				break;
			case 3:
				printf("\n Digite um cpf a ser procurado: ");
				scanf("%d", &valor);

				busca = buscar (raiz, valor);
				if (busca){
					printf("\n CPF escontrado: ");
					imprimirPessoa (busca->pessoa);
				}
				else {
					printf("\n CPF nao escontrado.");
				}
				break;
			case 4:
				printf("\n Altura da arvore: %d", altura(raiz));
				break;
			case 5:
				printf("\n Qtde de nos: %d", quantidadeNos(raiz));
				break;
			case 6:
				printf("\n Qtde de folhas: %d", quantidadeFolhas(raiz));
				break;
			case 7:
				show2(raiz);

				printf("\n CPF a ser removido: ");
				scanf("%d", &valor);

				raiz = remover (raiz, valor);
				break;
			default:
				printf ("\n Opcao invalida. \n");
				break;
		}

	} while (op != 0);

	return 0;
}