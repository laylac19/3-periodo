#include <stdio.h>
#include <stdlib.h>

typedef struct no {
	int dado;
	struct no *esq, *dir;
}No;

typedef struct {
	No *raiz; //raiz da arvore
	int tam;//qtde ou tam == quant de nós
}ArvB;

void show (No *raiz) { // ordenado
	if (raiz != NULL) {
		show (raiz->esq);
		printf("%d \t", raiz->dado);
		show (raiz->dir);
	}
}

No* inserirNovaVersao (No *raiz, int valor) { //retorna o endereço do nó
	if (raiz == NULL) {
		No *new = (No*)malloc(sizeof(No));
		new->dado = valor;
		new->esq = NULL;
		new->dir = NULL;
		return new;
	}
	else {
		if (valor < raiz->dado) {
			raiz->esq = inserirNovaVersao (raiz->esq, valor);
		}
		if (valor > raiz->dado) {
			raiz->dir = inserirNovaVersao (raiz->dir, valor);
		}
		return raiz;
	}
}
int tamanho (No *raiz) { //conta a qtde de nós
	if (raiz == NULL) {
		return 0;
	}
	else {
		return 1 + tamanho(raiz->esq) + tamanho(raiz->dir);
	}
}

int buscar (No *raiz, int chave) {
	//poderia ter um retorno binario (return no 1° e 2° if)
	if (raiz == NULL) {
		return -1; //n pode pertencer ao conjunto de elem da arvore
	}
	else {
		if (raiz->dado == chave) {
			return raiz->dado; //pode ser a chave ou dado
		}
		else {
			if (chave < raiz->dado) {
				return buscar (raiz->esq, chave);
			}
			else {
				return buscar (raiz->dir, chave);
			}
		}
	}
}

No* remover (No* raiz, int chave) {

	if (raiz == NULL) {
		printf("Valor nao encontrado. \n");
		return NULL;
	}
	else { 
		if (raiz->dado == chave) { //REMOVE NÓ FOLHA == sem filho
			if (raiz->esq == NULL && raiz->dir == NULL) {
				free(raiz);
				return NULL;
			}
			else { //REMOVE NÓ COM 1 FILHO
				if (raiz->esq != NULL || raiz->dir != NULL) {
					No *aux; //salva o endereço de memória do filho
					//verifica lado do filho
					if (raiz->esq != NULL) {
						aux = raiz->esq;
					}
					else {
						aux = raiz->dir;
					}
					free(raiz);
					return aux;
				}
				else { //REMOVE NÓ COM 2 FILHOS
					No *aux = raiz->esq;
					while (aux->dir != NULL) {
						aux = aux->dir;
					}
					//Pesso p = raiz->dado
					raiz->dado = aux->dado;
					aux->dado = chave;
					raiz->esq = remover (raiz->esq, chave);
					return raiz;
				}
			}
		}
		else {
			if (chave < raiz->dado) {
				raiz->esq = remover (raiz->esq, chave);
			}
			else {
				raiz->dir = remover (raiz->dir, chave);
			}
			return raiz;
		}
	}
}

int buscarNO (No *raiz, int chave) { 
	if (raiz == NULL) {
		return NULL; 
	}
	else {
		if (raiz->dado == chave) {
			return raiz; 
		}
		else {
			if (chave < raiz->dado) {
				return buscarNO (raiz->esq, chave);
			}
			else {
				return buscarNO (raiz->dir, chave);
			}
		}
	}
}

int alturaArv (No* raiz) { //calcular a altura da arvore
	//se raiz for nulo ou folha
	if (raiz == NULL || raiz->dir == NULL && raiz->esq == NULL) {
		return 0;
	}
	else {
		int esq = 1 + alturaArv (raiz->esq);
		int dir = 1+ alturaArv (raiz->dir);

		//retorna o maior
		if (esq > dir) {
			return esq;
		}
		else {
			return dir;
		}
	}
}

int alturaSubArv (No* raiz, chave) { //calcular a altura de uma sub arvore
	No *no = buscarNO (raiz, chave);
	if (no) {
		return alturaArv (no);
	}
	else {
		return -1;
	} 

}

int main(int argc, char const *argv[]) {
	
	int op, valor;
	ArvB arvore;

	No *raiz = NULL;

	do {
		printf("\n 0 - sair \n 1 - inserir \n 2 - imprimir \n 3 - buscar \n 4 - remover \n 5 - altura \n 6 - altura sub arvore \n");
		scanf("\n %d", &op);

		switch(op) {
			case 0:
				printf("\n SAINDO \n");
				break;
			case 1:
				printf("\n Digite um valor: ");
				scanf("%d", &valor);
				raiz = inserirNovaVersao (raiz, valor);
				break;
			case 2:
				printf("\n Impressao da arvore \n");
				show (raiz);
				printf ("\n");
				printf("Tamanho: %d \n", tamanho (raiz));
				break;
			case 3:
				printf("\n Digite um valor para buscar: ");
				scanf("%d", &valor);
				printf("Resultado da busca: %d \n", buscar (raiz, valor));
				break;
			case 4:
				printf("\n Valor a ser removido: ");
				scanf("%d", &valor);
				raiz = remover (raiz, valor);
				break;
			case 5:
				printf("\n Altura da arvore: %d ", alturaArv (raiz));
				break;
			case 6:
				printf("\n Digite um valor para calcular a altura: ");
				scanf("%d", &valor);
				printf("\n Altura da SubArvore: %d \n", alturaSubArv (raiz, valor));
				break;
			default:
				printf("\n Opicao Invalida");
		}

	} while (op != 0);

	return 0;
}