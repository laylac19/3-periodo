#include <stdio.h>
#include <stdlib.h>

typedef struct {
    char nome[50];
    int cpf;
}Pessoa;

typedef struct no {
    Pessoa pessoa;
    struct no *esq, *dir;
}No;

typedef struct {
    No *raiz; //raiz da arvore
    int tam;//qtde ou tam == quant de nós
}ArvB;

Pessoa lerPessoa () { //inserir uma pessoa na arvore e vai retornar esse pessoa
    Pessoa p;
    printf("Nome: \n");
    fgets(p.nome, 49, stdin);

    printf("CPF: \n");
    scanf("%d", &cpf);

    return p;
}

void imprimirPessoa (Pessoa p) { //imprime so  nó
    printf("\t Nome: %s \t CPF: %d \n", p.nome, p.cpf);
}

void showPessoa (No *raiz) { // ordem do nível
    if (raiz) {
        imprimirPessoa (raiz->pessoa);
        imprimirPessoa (raiz->esq);
        imprimirPessoa (raiz->dir);
    }
}

void showP (No *raiz) { // ordenado
    if (raiz) {
        showP (raiz->esq);
        printf("%d \t", raiz->pessoa);
        showP (raiz->dir);
    }
}

No* inserirNovaVersao (No *raiz, Pessoa p) { //retorna o endereço do nó
    if (raiz == NULL) {
        No *new = (No*)malloc(sizeof(No));
        new->pessoa = p;
        new->esq = NULL;
        new->dir = NULL;
        return new;
    }
    else {
        if (p.cpf < raiz->pessoa.cpf) {
            raiz->esq = inserirNovaVersao (raiz->esq, p);
        }
        else {
            raiz->dir = inserirNovaVersao (raiz->dir, p);
        }
        return raiz;
    }
}

int tamanho (No *raiz) { //conta a qtde de nós
    if (raiz == NULL) {
        return 0;
    }
    else {
        return 1 + tamanho(raiz->esq) + tamanho(raiz->dir);
    }
}

No* buscar (No *raiz, int cpf) {
    //poderia ter um retorno binario (return no 1° e 2° if)
    if (raiz == NULL) {
        return -1; //n pode pertencer ao conjunto de elem da arvore
    }
    else {
        if (raiz->pessoa.cpf == cpf) {
            return raiz->pessoa.cpf; //pode ser a cpf ou dado
        }
        else {
            if (cpf < raiz->pessoa.cpf) {
                return buscar (raiz->esq, cpf);
            }
            else {
                return buscar (raiz->dir, cpf);
            }
        }
    }
}

No* remover (No* raiz, int chave) { //chave é o cpf

    if (raiz == NULL) {
        printf("Valor nao encontrado. \n");
        return NULL;
    }
    else { 
        if (raiz->pessoa.cpf == chave) { //REMOVE NÓ FOLHA == sem filho
            if (raiz->esq == NULL && raiz->dir == NULL) {
                free(raiz);
                return NULL;
            }
            else { //REMOVE NÓ COM 1 FILHO
                if (raiz->esq != NULL || raiz->dir != NULL) {
                    No *aux; //salva o endereço de memória do filho
                    //verifica lado do filho
                    if (raiz->esq != NULL) {
                        aux = raiz->esq;
                    }
                    else {
                        aux = raiz->dir;
                    }
                    free(raiz);
                    return aux;
                }
                else { //REMOVE NÓ COM 2 FILHOS
                    Pessoa p;
                    No *aux = raiz->esq;
                    while (aux->dir != NULL) {
                        aux = aux->dir;
                    }
                    p = raiz->pessoa;
                    raiz->pessoa = aux->pessoa;
                    aux->pessoa = p;
                    raiz->esq = remover (raiz->esq, chave);
                    return raiz;
                }
            }
        }
        else {
            if (chave < raiz->pessoa.cpf) {
                raiz->esq = remover (raiz->esq, chave);
            }
            else {
                raiz->dir = remover (raiz->dir, chave);
            }
            return raiz;
        }
    }
}

int buscarNO (No *raiz, int chave) { 
    if (raiz == NULL) {
        return NULL; 
    }
    else {
        if (raiz->dado == chave) {
            return raiz; 
        }
        else {
            if (chave < raiz->dado) {
                return buscarNO (raiz->esq, chave);
            }
            else {
                return buscarNO (raiz->dir, chave);
            }
        }
    }
}

int alturaArv (No* raiz) { //calcular a altura da arvore
    //se raiz for nulo ou folha
    if (raiz == NULL || raiz->dir == NULL && raiz->esq == NULL) {
        return 0;
    }
    else {
        int esq = 1 + alturaArv (raiz->esq);
        int dir = 1+ alturaArv (raiz->dir);

        //retorna o maior
        if (esq > dir) {
            return esq;
        }
        else {
            return dir;
        }
    }
}

int alturaSubArv (No* raiz, chave) { //calcular a altura de uma sub arvore
    No *no = buscarNO (raiz, chave);
    if (no) {
        return alturaArv (no);
    }
    else {
        return -1;
    } 

}

int main(int argc, char const *argv[]) {
    
    int op, valor;
    ArvB arvore;

    No *raiz = NULL;

    do {
        printf("\n 0 - sair \n 1 - inserir \n 2 - imprimir \n 3 - buscar \n 4 - remover \n 5 - altura \n 6 - altura sub arvore \n");
        scanf("\n %d", &op);

        switch(op) {
            case 0:
                printf("\n SAINDO \n");
                break;
            case 1:
                inserirNovaVersao (&raiz, lerPessoa());
                break;
            case 2:
                printf("\n Impressao da arvore \n");
                show (raiz);
                printf ("\n");
                printf("Tamanho: %d \n", tamanho (raiz));
                break;
            case 3:
                printf("\n Digite CPF para buscar: ");
                scanf("%d", &valor);
                printf("Resultado da busca: %d \n", buscar (raiz, valor));
                break;
            case 4:
                printf("\n CPF a ser removido: ");
                scanf("%d", &valor);
                raiz = remover (raiz, valor);
                break;
            case 5:
                printf("\n Altura da arvore: %d ", alturaArv (raiz));
                break;
            case 6:
                printf("\n Digite um valor para calcular a altura: ");
                scanf("%d", &valor);
                printf("\n Altura da SubArvore: %d \n", alturaSubArv (raiz, valor));
                break;
            default:
                printf("\n Opicao Invalida");
        }

    } while (op != 0);

    return 0;
}