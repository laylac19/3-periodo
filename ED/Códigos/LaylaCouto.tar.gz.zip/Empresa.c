#include <stdio.h>
#include <stdlib.h>

#include "Empresa.h"

Pessoa lerPessoa () { //le uma pessoa na arvore e vai retornar essa pessoa
    Pessoa p;

    printf("\n Identificador: ");
    scanf("%s", &p.iden);
    scanf("%c");

    printf(" Nome: ");
    fgets(p.nome, 49, stdin);

    printf(" Idade: ");
    scanf("%d", &p.idade);

    printf(" Altura: ");
    scanf("%f", &p.altura);    

    return p;
}

Empresa lerEmpresa () { //le uma empresa na arvore e vai retornar essa empresa
    Empresa e;

    printf("\n Identificador: ");
    scanf("%s", &e.iden);

    printf(" CNPJ: ");
    scanf("%d", &e.cnpj);
    scanf("%c");

    printf(" Nome: ");
    fgets(e.nomeEmp, 49, stdin);

    printf(" Balanco: ");
    scanf("%lf", &e.balanco);  
    
    printf ("\n\n");  

    return e;
}

No* inserirPessoa (No *raiz, Pessoa p) { //retorna o endereço do nó
    if (raiz == NULL) {
        No *new = (No*)malloc(sizeof(No));
        new->pessoa = p;
        new->esq = NULL;
        new->dir = NULL;
        return new;
    }
    else {
        if (p.idade < raiz->pessoa.idade) {
            raiz->esq = inserirPessoa (raiz->esq, p);
        }
        else {
            raiz->dir = inserirPessoa (raiz->dir, p);
        }
        return raiz;
    }
}

No* inserirEmpresa (No *raiz, Empresa e) { //retorna o endereço do nó
    if (raiz == NULL) {
        No *new = (No*)malloc(sizeof(No));
        new->empresa = e;
        new->esq = NULL;
        new->dir = NULL;
        return new;
    }
    else {
        if (e.balanco < raiz->empresa.balanco) {
            raiz->esq = inserirEmpresa (raiz->esq, e);
        }
        else {
            raiz->dir = inserirEmpresa (raiz->dir, e);
        }
        return raiz;
    }
}

void modoJoao (No *n) {
    if (n) { //ordenado por idade
        modoJoao (n->esq);
        //imprimirPes (raiz->pessoa);
        printf("\t %s \t %s \t %d \t %.2f \n", n->pessoa.iden, n->pessoa.nome, n->pessoa.idade, n->pessoa.altura);
        modoJoao (n->esq);
    }
}

void modoVin (No *n) {
    if (n) { //ordenada pelos níveis
        //imprimirEmp (raiz->empresa);
        printf("\t %s \t %d \t %s \t %.2lf \n", n->empresa.iden, n->empresa.cnpj, n->empresa.nomeEmp, n->empresa.balanco);
        modoVin (n->esq);
        modoVin (n->dir);
    }
}

/*void imprimirPes (No *p) { //imprime so 1 nó
    printf("\t %s \t %s \t %d \t %f \n", p->pessoa.iden, p->pessoa.nome, p->pessoa.idade, p->pessoa.altura);
    //printf("\t %s \t %s \t %d \t %.2f \n", p->iden, p->nome, p->idade, p->altura);
}

void imprimirEmp (No *e) { //imprime so 1 nó
    printf("\t %s \t %d \t %s \t %lf \n", e->empresa.iden, e->empresa.cnpj, e->empresa.nomeEmp, e->empresa.balanco);
    //printf("\t %s \t %d \t %s \t %lf \n", e->iden, e->cnpj, e->nomeEmp, e->balanco);
}
*/