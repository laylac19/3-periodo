#include <stdio.h>
#include <stdlib.h>

#ifndef EMPRESA_H
#define EMPRESA_H


typedef struct {
    char iden[1]; //identificador
    char nome[50];
    int idade;
    float altura;
}Pessoa;

typedef struct {
    char iden[1]; //identificador
    int cnpj;
    char nomeEmp[50];
    double balanco;
}Empresa;

typedef struct no {
    Pessoa pessoa;
    Empresa empresa;
    struct no *esq, *dir;
}No;

Pessoa lerPessoa ();

Empresa lerEmpresa ();

No* inserirPessoa (No *raiz, Pessoa p);

No* inserirEmpresa (No *raiz, Empresa e);

void modoVin (No *n);

#endif