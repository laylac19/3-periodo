#include <stdio.h>
#include <stdlib.h>

#include "Empresa.h"

int main(int argc, char const *argv[]) {

    No *raiz = NULL;
    
    int op, valor;
    
    //ArvB arvore;
    do {
        printf("\n 0 - Sair \n 1 - Inserir Total de Itens \n 2 - Inserir Pessoa \n 3 - Inserir Empresa \n 4 - Imprimir \n");
        scanf("\n %d", &op);

        switch(op) {
            case 0:
                printf("\n\t\t SAINDO \n");
                break;
            case 1:
                printf("\n Insira o numero total de intens: ");
                scanf("%d", &valor);
                scanf("%c");
                //exit(1);
                break;
            case 2:
                printf("\n\n");
                printf("\n\t\t ENTRATA \n");
                raiz = inserirPessoa (raiz, lerPessoa());
                break;
            case 3:
                printf("\n\n");
                printf("\n\t\t ENTRATA \n");
                raiz = inserirEmpresa (raiz , lerEmpresa());
                break;
            case 4:
                printf("\n\n");
                printf("\t\t SAIDA \n");

                printf("Total de intens: %d \n", valor);

                modoJoao (raiz);
                modoVin (raiz);

                printf ("\n");
                break;
            default:
                printf("\n Opicao Invalida");
        }

    } while (op != 0);

    return 0;
}