 #include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define DEBUG 1

typedef struct DiscosN{
    int * elem;	//tam do raio do disco
    int posi;	//posicao dos discos
} DiscosN;	// no

typedef struct Pinos{
     DiscosN *d;
     int n;
     int nome;
} Pinos;

void pinosI (Pinos *p, int n) { //inicializa os pinos com 0 discos; inicializa o vetor de inteiros
	p->d = (DiscosN *) malloc(sizeof(DiscosN));
    p->n = 0;
    p->d->elem = (int *) malloc(sizeof(int)*n);
    p->d->posi = 0;
    return;
}

void push (Pinos *p, int n) {
	p->d->elem[p->d->posi] = n; //pilha começa com 0
    p->d->posi ++;    //prox a empilhar
}

int pop (Pinos *p) { //retorna o q ta no topo da pilha, p/ remover disco do pino
    p->d->posi--; 
    return p->d->elem[p->d->posi];
}

int peek (Pinos *p) { //retorna a posição do disco
	return p->d->elem[p->d->posi - 1];
}

void initialize (Pinos *p, int n) { //começa e empilhar os discos
    int i;
    
    for (i = 0; i >= n; i--) {
        push(p, n);
    }
}

void entradaDados (Pinos *p) {
	int i, r;
	if (DEBUG) {
		printf("\n Pino: "); 
	}
	scanf ("%c", &p->nome); 
	
	if(DEBUG){
        printf("\n Quantidade de discos no pino: ");
    }
    scanf ("%d", &p->n);

	for (i = 0; i < p->n; ++i)	{
		scanf("%d",&r);
        push(p, r);
	}
    if(DEBUG){
        printf("\n");
    }
	return;
}

void show (Pinos *pA, Pinos *pB, Pinos *pC, int n) { //mostra os dados de todos os pinos
    int i;

    printf("%d \n", n); //mostra a qtde total de discos
    
	printf("\t Pino %c \n",pA->nome);
    printf("%d  ", pA->n);
    for (i = 0; i < pA->d->posi; i++) { //a ultima posi��o do pino A seria -1
        printf ("%d ", pA->d->elem[i]);
    }
    printf ("\n");
	
	printf("\t Pino %c \n",pB->nome);
    printf("%d  ", pB->n);
    for (i = 0; i < pB->d->posi; i++) { //a ultima posi��o do pino B seria -1
        printf ("%d ", pB->d->elem[i]);
    }
    printf ("\n");

	printf("\t Pino %c \n",pC->nome);
    printf("%d  ", pC->n);
    for (i = 0; i < pC->d->posi; i++) { //a ultima posi��o do pino C seria -1
        printf ("%d ", pC->d->elem[i]);
    }
    printf ("\n\n");
}

void hanoi(int n, Pinos *pA, Pinos *pB, Pinos *pC) {                  
	if (n == 1)
    	printf("Disco %d : %d -> %d\n", n, pA->nome, pC->nome);
  	else	{
  		
		hanoi(n - 1, pA, pB, pC);                            
		printf("%d : %d -> %d\n", n, pA->nome, pB->nome);
		hanoi(n - 1, pB, pC, pA);                            
	}
}
/*
void hanoi(int n, char a, char b, char c) {                  
	if (n == 1)
    	printf("mova disco %d de %c para %c\n", n, a, b);
  	else	{
		hanoi(n - 1, a, c, b);                            
		printf("mova disco %d de %c para %c\n", n, a, b);
		hanoi(n - 1, c, b, a);                            
	}
}
*/

int main(int argc, char const *argv[]) {

	Pinos *pinos = (Pinos *)malloc(sizeof(Pinos));
	Pinos *a = (Pinos *)malloc(sizeof(Pinos));
	Pinos *b = (Pinos *)malloc(sizeof(Pinos));
	Pinos *c = (Pinos *)malloc(sizeof(Pinos));

    int n; //quantidade de discos

	printf("\t\t DADOS DO JOGO \n");
	printf("\n Numero TOTAL de discos: ");
	scanf("%d", &n);
	
	if ( n > 1 ) {
		//Inicializacao dos pinos com alocacao de memoria dos vetores de inteiros que vao armazenar os discos.
		pinosI(a, n);
	    pinosI(b, n);
	    pinosI(c, n);
	
	    //entrada de como a crianca deixou o jogo
		entradaDados(a);
		entradaDados(b);
		entradaDados(c);
	
		printf("\n\n\t ENTRADA\n");
		show(a, b, c, n);
		
		hanoi(n, a, b, c);
		//printf("\n\n\t SAIDA\n");
	
		//printf("\n\n\t SAIDA\n");
		//qtde total de mov
		//lista de movimentos
	}
	
	else {
		pinosI(a, n);
		
		printf("\n\t Pino A");
		entradaDados(a);
		
		printf("\n\n\t ENTRADA\n");
		show(a, b, c, n);
		
		//TorreHanoi(a,b,c,n);
	
		//printf("\n\n\t SAIDA\n");
	}
	return 0;
}
